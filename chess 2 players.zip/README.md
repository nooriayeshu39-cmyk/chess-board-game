# ♔ Python Chess Game ♚

A fully functional **2-player terminal chess game** built in Python with all basic chess rules implemented.

---

## 🎮 Features

- ✅ Full 2-player chess in the terminal
- ✅ All 6 piece types with correct movement rules
- ✅ Check & Checkmate detection
- ✅ Stalemate detection (Draw)
- ✅ Pawn promotion (auto-promotes to Queen)
- ✅ Move validation (can't leave your King in check)
- ✅ Captured pieces display
- ✅ Move history tracking
- ✅ Resign & Draw offer commands
- ✅ Play again option
- ✅ Clean terminal UI with Unicode chess symbols

---

## 📁 Project Structure

```
chess_game/
│
├── main.py       # Entry point - run this to start the game
├── game.py       # Game controller - main game loop & logic
├── board.py      # Chess board - setup, move execution, check detection
├── pieces.py     # All chess pieces with movement rules
├── player.py     # Player class
├── display.py    # Terminal UI - board rendering & messages
└── README.md     # This file
```

---

## ▶️ How to Run

### Requirements
- Python 3.6 or higher
- No external libraries needed!

### Run the game
```bash
git clone https://github.com/YOUR_USERNAME/python-chess-game.git
cd python-chess-game
python main.py
```

---

## 🕹️ How to Play

### Making Moves
Enter moves using **standard chess notation**:
```
e2 e4      → Move piece from e2 to e4
d7 d5      → Move piece from d7 to d5
g1 f3      → Move Knight from g1 to f3
```

The board uses standard chess coordinates:
- **Columns**: a (left) → h (right)
- **Rows**: 1 (White's side) → 8 (Black's side)

### Special Commands
| Command   | Action                        |
|-----------|-------------------------------|
| `help`    | Show controls guide           |
| `resign`  | Forfeit the game              |
| `draw`    | Offer/accept a draw           |
| `history` | View recent move history      |

---

## ♟️ Chess Pieces & Movement

| Piece   | Symbol | Movement |
|---------|--------|----------|
| King    | ♔ ♚   | 1 square any direction |
| Queen   | ♕ ♛   | Any direction, any distance |
| Rook    | ♖ ♜   | Horizontal & vertical |
| Bishop  | ♗ ♝   | Diagonal only |
| Knight  | ♘ ♞   | L-shape (can jump pieces) |
| Pawn    | ♙ ♟   | Forward 1 (or 2 from start), captures diagonally |

---

## 🏆 Win Conditions

| Condition    | Result                                    |
|--------------|-------------------------------------------|
| **Checkmate**  | Opponent's King has no escape → You Win! |
| **Stalemate**  | Opponent can't move but not in check → Draw |
| **Resign**     | Current player forfeits → Other player wins |
| **Draw**       | Both players agree → Draw |

---

## 📸 Screenshot

```
==================================================
         ♔  PYTHON CHESS GAME  ♚
         2 Player Terminal Chess
==================================================

  ♟  Player 2 (Black)
  Captured: None

    a  b  c  d  e  f  g  h
  +--+--+--+--+--+--+--+--+
8 | ♜ | ♞ | ♝ | ♛ | ♚ | ♝ | ♞ | ♜ | 8
  +--+--+--+--+--+--+--+--+
7 | ♟ | ♟ | ♟ | ♟ | ♟ | ♟ | ♟ | ♟ | 7
  +--+--+--+--+--+--+--+--+
...
```

---

## 🛠️ Code Overview

### `pieces.py`
Each piece class extends the base `Piece` class and implements `get_valid_moves()`:
- `Pawn` - handles forward movement and diagonal captures
- `Rook` - slides horizontally/vertically
- `Knight` - L-shaped jumps
- `Bishop` - slides diagonally
- `Queen` - combines Rook + Bishop
- `King` - single step any direction

### `board.py`
- Sets up the initial board
- Validates moves (prevents leaving King in check)
- Detects check, checkmate, and stalemate
- Handles piece captures and pawn promotion

### `game.py`
- Manages game flow and player turns
- Parses chess notation input
- Handles special commands (resign, draw, help)
- Tracks move history

### `display.py`
- Renders the board in the terminal
- Shows captured pieces, move history
- Provides styled messages and prompts

---

## 👨‍💻 Author

Built with Python as a learning project for OOP and game logic implementation.

---

## 📄 License

MIT License - feel free to use and modify!
