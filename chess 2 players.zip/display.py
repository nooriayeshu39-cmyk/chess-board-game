# display.py - Chess Board Display in Terminal

import os


def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')


def print_header():
    """Print game title header"""
    print("=" * 50)
    print("         ♔  PYTHON CHESS GAME  ♚")
    print("         2 Player Terminal Chess")
    print("=" * 50)


def print_board(board, player1, player2, highlighted_moves=None, selected=None):
    """
    Display the chess board with pieces.
    
    Args:
        board: Board object
        player1: White player
        player2: Black player
        highlighted_moves: List of (row, col) tuples to highlight
        selected: (row, col) of selected piece
    """
    clear_screen()
    print_header()
    
    # Player info - Black (top)
    print(f"\n  ♟  {player2.name} (Black)")
    print(f"  Captured: {player2.get_captured_display()}")
    print()
    
    # Column labels
    print("    a  b  c  d  e  f  g  h")
    print("  +" + "--+" * 8)
    
    for row in range(8):
        # Row number (8 at top, 1 at bottom)
        print(f"{8 - row} |", end="")
        
        for col in range(8):
            piece = board.grid[row][col]
            
            # Check if this cell is highlighted
            is_selected = selected and (row, col) == selected
            is_valid_move = highlighted_moves and (row, col) in highlighted_moves
            
            if is_selected:
                # Selected piece - show with brackets
                cell = f"[{piece}]" if piece else "[ ]"
                print(cell, end="|")
            elif is_valid_move:
                # Valid move destination
                if piece:
                    print(f"*{piece}*", end="|")  # Capture available
                else:
                    print(" · ", end="|")          # Empty square can move here
            else:
                # Normal cell
                if piece:
                    print(f" {piece} ", end="|")
                else:
                    # Checkerboard pattern for empty squares
                    if (row + col) % 2 == 0:
                        print("   ", end="|")
                    else:
                        print("   ", end="|")
        
        print(f" {8 - row}")  # Row number on right side
    
    print("  +" + "--+" * 8)
    print("    a  b  c  d  e  f  g  h")
    print()
    
    # Player info - White (bottom)
    print(f"  ♙  {player1.name} (White)")
    print(f"  Captured: {player1.get_captured_display()}")
    print()


def print_message(message, msg_type="info"):
    """Print a styled message"""
    icons = {
        "info":    "ℹ️ ",
        "success": "✅",
        "warning": "⚠️ ",
        "error":   "❌",
        "check":   "🔴",
    }
    icon = icons.get(msg_type, "  ")
    print(f"  {icon}  {message}")


def print_move_history(history, last_n=5):
    """Print the last N moves"""
    if not history:
        return
    print("\n  📋 Recent Moves:")
    start = max(0, len(history) - last_n)
    for i, move in enumerate(history[start:], start + 1):
        print(f"     {i}. {move}")


def get_input(prompt):
    """Get input from user with styled prompt"""
    return input(f"  ➤  {prompt}: ").strip().lower()


def print_game_over(winner, reason):
    """Print game over screen"""
    print("\n" + "=" * 50)
    print("           🏆  GAME OVER  🏆")
    print("=" * 50)
    if winner:
        print(f"\n  🎉  {winner} WINS!")
    else:
        print(f"\n  🤝  IT'S A DRAW!")
    print(f"  Reason: {reason}")
    print("\n" + "=" * 50)


def print_controls():
    """Print game controls help"""
    print("\n  📖 HOW TO PLAY:")
    print("  ─────────────────────────────────")
    print("  • Enter moves like: e2 e4")
    print("    (from_square to_square)")
    print("  • Type 'resign' to forfeit")
    print("  • Type 'draw' to offer a draw")
    print("  • Type 'help' to see this again")
    print("  • Type 'history' to see moves")
    print("  ─────────────────────────────────\n")
